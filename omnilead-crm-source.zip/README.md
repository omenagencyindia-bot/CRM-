# OmniLead CRM

A soft-lavender, responsive React CRM connected to your existing Supabase project.

## Included
- Friendly animated sign-in / sign-up screen with Supabase Auth
- Overview dashboard and live counts
- Lead CRUD, search, status filtering, quick status updates, and delete confirmation
- Follow-up task creation, completion toggles, filtering and deletion
- Activity timeline
- Settings/integration status UI for Supabase and future n8n workflows
- Row Level Security policies that scope leads, tasks and activities to the signed-in owner

## Setup
1. Install Node.js LTS.
2. Extract the project folder and open a terminal inside it.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. The Supabase URL and publishable key are prefilled for the selected project. The publishable key is intended for browser apps; never add a service-role/secret key.
6. Run `npm run dev` and open the local URL shown by Vite.
7. Create an account in the app. If email confirmation is enabled in Supabase Auth, confirm the email before signing in.
8. Run `npm run build` before deploying.

## Security
- Browser uses only the Supabase publishable key. Never expose a service-role/secret key in frontend code.
- Database policies were applied to the Supabase project `jctcpwwedzwkpivsqwff` and verified by querying `pg_policies`.
- Existing permissive anonymous read/insert policies on `public.leads` were removed. The table is now owner-scoped for authenticated users.
- New records include `owner_id = auth.uid()`. RLS remains the actual security boundary.
- This first version is personal-workspace/owner scoped. For a multi-user shared team CRM, add organisations, memberships, and role-aware policies before inviting client teams.

## n8n next step
Do not put service-role keys in the browser. Use n8n Credentials for server-side secrets. Build a webhook with authentication, validate payloads, then insert/update records through a server-side credential. Avoid unauthenticated public endpoints for writing CRM data.

## Notes
The CRM is a runnable source project, not yet deployed to a public domain. Deploy the built `dist/` folder to your hosting provider after adding environment variables.
