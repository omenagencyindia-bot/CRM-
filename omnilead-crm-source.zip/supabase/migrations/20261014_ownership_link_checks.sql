-- Tighten linked-record ownership: tasks and activities may only reference the signed-in owner's leads.
drop policy if exists "crm_tasks_insert_own" on public.crm_tasks;
drop policy if exists "crm_tasks_update_own" on public.crm_tasks;
create policy "crm_tasks_insert_own" on public.crm_tasks for insert to authenticated with check ((select auth.uid()) = owner_id and (lead_id is null or exists (select 1 from public.leads l where l.id = crm_tasks.lead_id and l.owner_id = (select auth.uid()))));
create policy "crm_tasks_update_own" on public.crm_tasks for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id and (lead_id is null or exists (select 1 from public.leads l where l.id = crm_tasks.lead_id and l.owner_id = (select auth.uid()))));
drop policy if exists "crm_activities_insert_own" on public.crm_activities;
drop policy if exists "crm_activities_update_own" on public.crm_activities;
create policy "crm_activities_insert_own" on public.crm_activities for insert to authenticated with check ((select auth.uid()) = owner_id and (lead_id is null or exists (select 1 from public.leads l where l.id = crm_activities.lead_id and l.owner_id = (select auth.uid()))));
create policy "crm_activities_update_own" on public.crm_activities for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id and (lead_id is null or exists (select 1 from public.leads l where l.id = crm_activities.lead_id and l.owner_id = (select auth.uid()))));
