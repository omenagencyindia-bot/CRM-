-- This migration has already been applied to project jctcpwwedzwkpivsqwff.
-- Kept here for source control / reference. Do not re-run blindly.
alter table public.leads add column if not exists owner_id uuid references auth.users(id) on delete cascade;
drop policy if exists public_read_leads on public.leads;
drop policy if exists public_insert_leads on public.leads;
drop policy if exists "leads_select_own" on public.leads;
drop policy if exists "leads_insert_own" on public.leads;
drop policy if exists "leads_update_own" on public.leads;
drop policy if exists "leads_delete_own" on public.leads;
alter table public.leads enable row level security;
create policy "leads_select_own" on public.leads for select to authenticated using ((select auth.uid()) = owner_id);
create policy "leads_insert_own" on public.leads for insert to authenticated with check ((select auth.uid()) = owner_id);
create policy "leads_update_own" on public.leads for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "leads_delete_own" on public.leads for delete to authenticated using ((select auth.uid()) = owner_id);
create table if not exists public.crm_tasks (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id) on delete cascade,
 lead_id uuid references public.leads(id) on delete set null, title text not null check(char_length(trim(title)) between 1 and 160),
 description text, due_date date, status text not null default 'pending' check(status in ('pending','completed')),
 priority text not null default 'normal' check(priority in ('low','normal','high')), created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index if not exists crm_tasks_owner_due_idx on public.crm_tasks(owner_id,due_date);
alter table public.crm_tasks enable row level security;
create policy "crm_tasks_select_own" on public.crm_tasks for select to authenticated using ((select auth.uid()) = owner_id);
create policy "crm_tasks_insert_own" on public.crm_tasks for insert to authenticated with check ((select auth.uid()) = owner_id);
create policy "crm_tasks_update_own" on public.crm_tasks for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "crm_tasks_delete_own" on public.crm_tasks for delete to authenticated using ((select auth.uid()) = owner_id);
create table if not exists public.crm_activities (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id) on delete cascade,
 lead_id uuid references public.leads(id) on delete set null, activity_type text not null default 'note'
 check(activity_type in ('note','call','whatsapp','email','status_change','created')),
 content text not null check(char_length(trim(content)) between 1 and 2000), created_at timestamptz not null default now()
);
create index if not exists crm_activities_owner_created_idx on public.crm_activities(owner_id,created_at desc);
alter table public.crm_activities enable row level security;
create policy "crm_activities_select_own" on public.crm_activities for select to authenticated using ((select auth.uid()) = owner_id);
create policy "crm_activities_insert_own" on public.crm_activities for insert to authenticated with check ((select auth.uid()) = owner_id);
create policy "crm_activities_update_own" on public.crm_activities for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "crm_activities_delete_own" on public.crm_activities for delete to authenticated using ((select auth.uid()) = owner_id);
create or replace function public.set_crm_updated_at() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists crm_tasks_set_updated_at on public.crm_tasks;
create trigger crm_tasks_set_updated_at before update on public.crm_tasks for each row execute function public.set_crm_updated_at();
grant select,insert,update,delete on public.leads to authenticated;
grant select,insert,update,delete on public.crm_tasks to authenticated;
grant select,insert,update,delete on public.crm_activities to authenticated;
