import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, CalendarDays, Check,
  CheckCircle2, ChevronDown, CircleHelp, Clock3, Command, ContactRound,
  Filter, LayoutDashboard, LogOut, Mail, Menu, MessageCircle, MoreHorizontal,
  Pencil, Plus, Search, Settings2, Sparkles, Trash2, UsersRound, X,
  Phone, KanbanSquare, ListTodo, LoaderCircle, Eye, EyeOff, AlertCircle
} from 'lucide-react';
import './style.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;
const STATUSES = ['New Lead', 'Contacted', 'Qualified', 'Won', 'Lost'];
const emptyLead = { customer_name:'', phone:'', email:'', service_or_product:'', source:'Website', lead_status:'New Lead', notes:'', follow_up_date:'' };
const fmtDate = (date) => date ? new Date(`${date}T00:00:00`).toLocaleDateString('en-IN',{day:'numeric',month:'short'}) : 'Not set';
const initials = (name='New Lead') => name.trim().split(/\s+/).slice(0,2).map(s=>s[0]?.toUpperCase()).join('') || 'NL';

function App() {
  const [session,setSession] = useState(null);
  const [authReady,setAuthReady] = useState(false);
  const [authMode,setAuthMode] = useState('login');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [showPassword,setShowPassword] = useState(false);
  const [authBusy,setAuthBusy] = useState(false);
  const [authMessage,setAuthMessage] = useState('');
  const [page,setPage] = useState('Overview');
  const [leads,setLeads] = useState([]);
  const [tasks,setTasks] = useState([]);
  const [activities,setActivities] = useState([]);
  const [loading,setLoading] = useState(false);
  const [notice,setNotice] = useState('');
  const [query,setQuery] = useState('');
  const [statusFilter,setStatusFilter] = useState('All statuses');
  const [modal,setModal] = useState(null);
  const [leadForm,setLeadForm] = useState(emptyLead);
  const [taskForm,setTaskForm] = useState({title:'',description:'',due_date:'',priority:'normal',lead_id:''});
  const [saving,setSaving] = useState(false);
  const [mobileNav,setMobileNav] = useState(false);

  useEffect(() => {
    if (!supabase) { setAuthReady(true); return; }
    supabase.auth.getSession().then(({data})=>{setSession(data.session);setAuthReady(true);});
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,nextSession)=>setSession(nextSession));
    return ()=>subscription.unsubscribe();
  }, []);

  useEffect(()=>{ if(session) loadAll(); },[session]);

  async function loadAll() {
    if(!supabase || !session?.user) return;
    setLoading(true);
    const uid = session.user.id;
    const [l,t,a] = await Promise.all([
      supabase.from('leads').select('*').eq('owner_id',uid).order('created_at',{ascending:false}),
      supabase.from('crm_tasks').select('*').eq('owner_id',uid).order('due_date',{ascending:true}),
      supabase.from('crm_activities').select('*').eq('owner_id',uid).order('created_at',{ascending:false}).limit(8)
    ]);
    const errors=[l.error,t.error,a.error].filter(Boolean);
    if(errors.length) showNotice(errors[0].message);
    setLeads(l.data||[]); setTasks(t.data||[]); setActivities(a.data||[]);
    setLoading(false);
  }
  function showNotice(message){ setNotice(message); window.setTimeout(()=>setNotice(''),4200); }

  async function handleAuth(e) {
    e.preventDefault(); setAuthMessage('');
    if(!supabase){setAuthMessage('Add your Supabase URL and publishable key to .env first.');return;}
    setAuthBusy(true);
    const result = authMode==='login'
      ? await supabase.auth.signInWithPassword({email,password})
      : await supabase.auth.signUp({email,password});
    setAuthBusy(false);
    if(result.error) setAuthMessage(result.error.message);
    else if(authMode==='signup' && !result.data.session) setAuthMessage('Account created. Check your email to confirm it, then sign in.');
  }

  async function signOut(){await supabase.auth.signOut();setLeads([]);setTasks([]);setActivities([]);setPage('Overview');}
  async function logActivity(leadId, type, content) {
    if(!content?.trim()) return;
    const {error}=await supabase.from('crm_activities').insert({owner_id:session.user.id,lead_id:leadId||null,activity_type:type,content:content.trim()});
    if(error) showNotice(`Saved, but activity log failed: ${error.message}`);
  }
  function openNewLead(){setLeadForm(emptyLead);setModal({type:'lead'});}
  function openEditLead(lead){setLeadForm({...emptyLead,...lead,follow_up_date:lead.follow_up_date||''});setModal({type:'lead',lead});}
  async function saveLead(e) {
    e.preventDefault(); setSaving(true);
    const payload={...leadForm,owner_id:session.user.id,follow_up_date:leadForm.follow_up_date||null,updated_at:new Date().toISOString()};
    delete payload.id; delete payload.created_at; delete payload.owner_id;
    let result;
    if(modal.lead) result=await supabase.from('leads').update(payload).eq('id',modal.lead.id).eq('owner_id',session.user.id).select().single();
    else result=await supabase.from('leads').insert({...payload,owner_id:session.user.id,lead_id:`OL-${Date.now().toString().slice(-8)}`}).select().single();
    setSaving(false);
    if(result.error){showNotice(result.error.message);return;}
    await logActivity(result.data.id,modal.lead?'note':'created',modal.lead?`Updated lead details for ${result.data.customer_name||'contact'}.`:`Added lead ${result.data.customer_name||'New lead'}.`);
    setModal(null);showNotice(modal.lead?'Lead updated successfully':'New lead added');loadAll();
  }
  async function deleteLead(lead) {
    if(!window.confirm(`Delete ${lead.customer_name||'this lead'}? This cannot be undone.`)) return;
    const {error}=await supabase.from('leads').delete().eq('id',lead.id).eq('owner_id',session.user.id);
    if(error) showNotice(error.message); else {showNotice('Lead deleted');loadAll();}
  }
  async function updateStatus(lead,status) {
    const {error}=await supabase.from('leads').update({lead_status:status,updated_at:new Date().toISOString()}).eq('id',lead.id).eq('owner_id',session.user.id);
    if(error) showNotice(error.message);
    else {await logActivity(lead.id,'status_change',`${lead.customer_name||'Lead'} moved to ${status}.`);showNotice(`Status changed to ${status}`);loadAll();}
  }
  async function saveTask(e) {
    e.preventDefault();setSaving(true);
    const payload={...taskForm,owner_id:session.user.id,lead_id:taskForm.lead_id||null,due_date:taskForm.due_date||null};
    const {error}=await supabase.from('crm_tasks').insert(payload);
    setSaving(false);
    if(error){showNotice(error.message);return;}
    setModal(null);setTaskForm({title:'',description:'',due_date:'',priority:'normal',lead_id:''});showNotice('Follow-up added');loadAll();
  }
  async function toggleTask(task) {
    const next=task.status==='completed'?'pending':'completed';
    const {error}=await supabase.from('crm_tasks').update({status:next}).eq('id',task.id).eq('owner_id',session.user.id);
    if(error) showNotice(error.message); else loadAll();
  }
  async function deleteTask(task) {
    if(!window.confirm(`Delete task “${task.title}”?`))return;
    const {error}=await supabase.from('crm_tasks').delete().eq('id',task.id).eq('owner_id',session.user.id);
    if(error)showNotice(error.message);else{showNotice('Task deleted');loadAll();}
  }

  const filteredLeads=useMemo(()=>leads.filter(l=>{
    const q=query.toLowerCase();
    const match=[l.customer_name,l.phone,l.email,l.service_or_product,l.source].some(v=>(v||'').toLowerCase().includes(q));
    return match&&(statusFilter==='All statuses'||l.lead_status===statusFilter);
  }),[leads,query,statusFilter]);
  const pending=tasks.filter(t=>t.status!=='completed');
  const dueToday=pending.filter(t=>t.due_date===new Date().toISOString().slice(0,10));
  const won=leads.filter(l=>l.lead_status==='Won').length;
  const conversion=leads.length?Math.round(won/leads.length*100):0;

  if(!authReady) return <div className="loading-screen"><div className="brand-mark"><Sparkles/></div><LoaderCircle className="spin"/> Getting things ready…</div>;
  if(!session) return <Login email={email} setEmail={setEmail} password={password} setPassword={setPassword} showPassword={showPassword} setShowPassword={setShowPassword} authMode={authMode} setAuthMode={setAuthMode} authBusy={authBusy} authMessage={authMessage} handleAuth={handleAuth} configured={!!supabase}/>;

  const nav=[{label:'WORKSPACE',items:[['Overview',LayoutDashboard],['Leads',UsersRound],['Follow-ups',CalendarDays],['Activity',Activity]]},{label:'PREFERENCES',items:[['Settings',Settings2]]}];
  const userEmail=session.user.email||'Your account';
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'mobile-open':''}`}>
      <div className="brand"><div className="brand-mark"><Sparkles size={20}/></div><div><strong>omni<span>lead</span></strong><small>YOUR FRIENDLY CRM</small></div><button className="icon-btn close-mobile" onClick={()=>setMobileNav(false)}><X size={18}/></button></div>
      <button className="workspace-switch"><div className="workspace-avatar">O</div><span><b>My workspace</b><small>Personal workspace</small></span><ChevronDown size={16}/></button>
      {nav.map(group=><div className="nav-group" key={group.label}><div className="nav-label">{group.label}</div>{group.items.map(([name,Icon])=><button key={name} className={`nav-item ${page===name?'active':''}`} onClick={()=>{setPage(name);setMobileNav(false);}}><Icon size={18}/><span>{name}</span>{name==='Follow-ups'&&pending.length>0&&<span className="nav-count">{pending.length}</span>}</button>)}</div>)}
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={18}/></div><b>Need a little help?</b><p>Keep things simple. You’ve got this.</p><button onClick={()=>showNotice('Tip: use the + Add lead button to create your first contact.')}>Quick tip <span>↗</span></button></div><div className="profile-row"><div className="profile-avatar">{initials(userEmail)}</div><div className="profile-text"><b>{userEmail.split('@')[0]}</b><small>{userEmail}</small></div><button className="icon-btn" title="Sign out" onClick={signOut}><LogOut size={17}/></button></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="icon-btn menu-btn" onClick={()=>setMobileNav(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-actions"><div className="secure-chip"><span/> All changes saved</div><button className="icon-btn notification-btn" title="Notifications" onClick={()=>setPage('Follow-ups')}><Bell size={18}/>{pending.length>0&&<i/>}</button><div className="top-avatar">{initials(userEmail)}</div></div></header>
      <div className="page-content">
        {page==='Overview'&&<Overview leads={leads} tasks={tasks} activities={activities} dueToday={dueToday} pending={pending} won={won} conversion={conversion} onNewLead={openNewLead} onNewTask={()=>setModal({type:'task'})} onPage={setPage} onToggleTask={toggleTask} loading={loading}/>}
        {page==='Leads'&&<LeadsPage leads={filteredLeads} query={query} setQuery={setQuery} statusFilter={statusFilter} setStatusFilter={setStatusFilter} onNew={openNewLead} onEdit={openEditLead} onDelete={deleteLead} onStatus={updateStatus} loading={loading}/>}
        {page==='Follow-ups'&&<TasksPage tasks={tasks} onNew={()=>setModal({type:'task'})} onToggle={toggleTask} onDelete={deleteTask}/>}
        {page==='Activity'&&<ActivityPage activities={activities} leads={leads}/>}
        {page==='Settings'&&<SettingsPage userEmail={userEmail} onSignOut={signOut} showNotice={showNotice}/>}
      </div>
      <footer className="footer"><span>Made with <span className="heart">♥</span> for better connections</span><span>OmniLead CRM <b>·</b> v1.0</span></footer>
    </main>
    {notice&&<div className="toast"><CheckCircle2 size={18}/><span>{notice}</span><button onClick={()=>setNotice('')}><X size={16}/></button></div>}
    {modal?.type==='lead'&&<Modal title={modal.lead?'Edit lead':'Add a new lead'} subtitle="Just the essentials. You can add more details later." onClose={()=>setModal(null)}><form onSubmit={saveLead} className="modal-form">
      <label>Full name <em>*</em><input required autoFocus value={leadForm.customer_name||''} onChange={e=>setLeadForm({...leadForm,customer_name:e.target.value})} placeholder="e.g. Priya Sharma"/></label>
      <div className="form-grid"><label>Phone number<input value={leadForm.phone||''} onChange={e=>setLeadForm({...leadForm,phone:e.target.value})} placeholder="+91 98765 43210"/></label><label>Email address<input type="email" value={leadForm.email||''} onChange={e=>setLeadForm({...leadForm,email:e.target.value})} placeholder="priya@example.com"/></label></div>
      <div className="form-grid"><label>Interested in<input value={leadForm.service_or_product||''} onChange={e=>setLeadForm({...leadForm,service_or_product:e.target.value})} placeholder="Website, appointment…"/></label><label>Lead source<select value={leadForm.source||'Website'} onChange={e=>setLeadForm({...leadForm,source:e.target.value})}>{['Website','WhatsApp','Facebook Ads','Instagram','Referral','Phone call','Walk-in','Other'].map(s=><option key={s}>{s}</option>)}</select></label></div>
      <div className="form-grid"><label>Lead status<select value={leadForm.lead_status||'New Lead'} onChange={e=>setLeadForm({...leadForm,lead_status:e.target.value})}>{STATUSES.map(s=><option key={s}>{s}</option>)}</select></label><label>Follow-up date<input type="date" value={leadForm.follow_up_date||''} onChange={e=>setLeadForm({...leadForm,follow_up_date:e.target.value})}/></label></div>
      <label>Notes<textarea rows="3" value={leadForm.notes||''} onChange={e=>setLeadForm({...leadForm,notes:e.target.value})} placeholder="Anything useful to remember…"/></label>
      <div className="modal-actions"><button type="button" className="btn btn-ghost" onClick={()=>setModal(null)}>Cancel</button><button className="btn btn-primary" disabled={saving}>{saving?<LoaderCircle className="spin" size={17}/>:<Check size={17}/>} {modal.lead?'Save changes':'Add lead'}</button></div>
    </form></Modal>}
    {modal?.type==='task'&&<Modal title="Add a follow-up" subtitle="A small reminder can make a big difference." onClose={()=>setModal(null)}><form onSubmit={saveTask} className="modal-form">
      <label>What needs doing? <em>*</em><input required autoFocus value={taskForm.title} onChange={e=>setTaskForm({...taskForm,title:e.target.value})} placeholder="e.g. Call Priya about the proposal"/></label>
      <div className="form-grid"><label>Due date<input type="date" value={taskForm.due_date} onChange={e=>setTaskForm({...taskForm,due_date:e.target.value})}/></label><label>Priority<select value={taskForm.priority} onChange={e=>setTaskForm({...taskForm,priority:e.target.value})}><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option></select></label></div>
      <label>Related lead<select value={taskForm.lead_id} onChange={e=>setTaskForm({...taskForm,lead_id:e.target.value})}><option value="">No specific lead</option>{leads.map(l=><option key={l.id} value={l.id}>{l.customer_name||l.phone||'Unnamed lead'}</option>)}</select></label>
      <label>Notes<textarea rows="3" value={taskForm.description} onChange={e=>setTaskForm({...taskForm,description:e.target.value})} placeholder="Optional details…"/></label>
      <div className="modal-actions"><button type="button" className="btn btn-ghost" onClick={()=>setModal(null)}>Cancel</button><button className="btn btn-primary" disabled={saving}>{saving?<LoaderCircle className="spin" size={17}/>:<Plus size={17}/>} Add reminder</button></div>
    </form></Modal>}
  </div>;
}

function Login({email,setEmail,password,setPassword,showPassword,setShowPassword,authMode,setAuthMode,authBusy,authMessage,handleAuth,configured}) {
 return <div className="login-screen"><div className="login-decoration blob-one"/><div className="login-decoration blob-two"/><div className="login-layout"><div className="login-story"><div className="brand login-brand"><div className="brand-mark"><Sparkles size={20}/></div><div><strong>omni<span>lead</span></strong><small>YOUR FRIENDLY CRM</small></div></div><div className="story-content"><div className="eyebrow"><Sparkles size={14}/> A little more organised, a lot less stressed</div><h1>Good things<br/>start with a <span>hello.</span></h1><p>All your people, follow-ups and bright ideas — in one lovely, easy place.</p><div className="story-points"><div><span className="point-icon lilac"><UsersRound size={18}/></span><span><b>People, made simple</b><small>Every contact right where you need it.</small></span></div><div><span className="point-icon peach"><CalendarDays size={18}/></span><span><b>Never miss a follow-up</b><small>Gentle reminders for the important things.</small></span></div><div><span className="point-icon mint"><CheckCircle2 size={18}/></span><span><b>Progress you can see</b><small>Less busywork. More meaningful work.</small></span></div></div></div><div className="login-quote">“Every lead matters. Every connection counts.”</div></div><div className="login-panel-wrap"><div className="login-panel"><div className="welcome-icon"><Sparkles size={23}/></div><div className="welcome-label">YOUR WORKSPACE AWAITS</div><h2>{authMode==='login'?'Welcome back!':'Let’s get started!'}</h2><p className="panel-sub">{authMode==='login'?'Pick up right where the good things happen.':'Create your account and make work feel lighter.'}</p>
 <form onSubmit={handleAuth} className="login-form"><label>Email address<div className="input-icon"><Mail size={17}/><input type="email" required autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com"/></div></label><label>Password<div className="input-icon"><span className="lock-symbol">●</span><input type={showPassword?'text':'password'} required minLength={6} autoComplete={authMode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/><button type="button" className="show-password" onClick={()=>setShowPassword(!showPassword)}>{showPassword?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></label>{authMessage&&<div className="auth-message"><AlertCircle size={16}/>{authMessage}</div>}<button className="btn btn-primary login-submit" disabled={authBusy||!configured}>{authBusy?<LoaderCircle className="spin" size={18}/>:null}{authMode==='login'?'Sign in to your workspace':'Create my account'}<span>→</span></button></form>
 {!configured&&<div className="config-warning">Setup needed: add the Supabase URL and publishable key to your <code>.env</code> file.</div>}<div className="auth-switch">{authMode==='login'?"New around here?":"Already have an account?"} <button onClick={()=>{setAuthMode(authMode==='login'?'signup':'login');}}>{authMode==='login'?'Create an account':'Sign in instead'}</button></div><div className="login-secure"><span/> Your data is private and securely stored</div></div><div className="login-foot">A calmer way to keep in touch <span>✦</span></div></div></div></div>
}

function PageHeading({eyebrow,title,subtitle,action}) {return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>}
function Overview({leads,tasks,activities,dueToday,pending,won,conversion,onNewLead,onNewTask,onPage, onToggleTask,loading}) {
 const today=new Date().toLocaleDateString('en-IN',{weekday:'long',month:'long',day:'numeric'});
 const recent=leads.slice(0,5);
 return <><PageHeading eyebrow={today} title="Welcome back, friend ✨" subtitle="A fresh little overview of everything moving forward." action={<button className="btn btn-primary" onClick={onNewLead}><Plus size={18}/> Add a lead</button>}/>
 <div className="hero-banner"><div className="hero-copy"><div className="hero-pill"><Sparkles size={13}/> YOUR DAILY LITTLE WIN</div><h2>Small steps make<br/>lovely progress.</h2><p>You've got this. Let's make today count, one connection at a time.</p><button className="hero-button" onClick={()=>onPage('Leads')}>Explore your leads <span>→</span></button></div><div className="hero-art"><div className="art-sun"/><div className="art-card art-card-one"><UsersRound size={19}/><span>People first</span></div><div className="art-card art-card-two"><CheckCircle2 size={19}/><span>All in flow</span></div><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-star star-a">✦</div><div className="art-star star-b">✧</div></div></div>
 <div className="stats-grid"><StatCard title="Total leads" value={leads.length} note="All your connections" icon={UsersRound} tint="purple" trend="Your network"/><StatCard title="Need a follow-up" value={pending.length} note={`${dueToday.length} due today`} icon={CalendarDays} tint="peach" trend={dueToday.length?'Today is the day':'Stay on track'}/><StatCard title="Won leads" value={won} note="Lovely wins so far" icon={CheckCircle2} tint="mint" trend="Keep it up"/><StatCard title="Conversion rate" value={`${conversion}%`} note="Leads marked as won" icon={ArrowUpRight} tint="blue" trend="Your progress"/></div>
 <div className="dashboard-grid"><section className="panel leads-panel"><div className="panel-heading"><div><h3>Recent leads <span className="soft-count">{leads.length}</span></h3><p>Your newest connections, all in one place.</p></div><button className="text-link" onClick={()=>onPage('Leads')}>View all <span>→</span></button></div>{loading?<EmptyInline>Loading your leads…</EmptyInline>:recent.length===0?<EmptyState icon={UsersRound} title="Your story starts here" desc="Add your first lead and keep every connection close." action={<button className="btn btn-primary btn-small" onClick={onNewLead}><Plus size={16}/> Add your first lead</button>}/>:<div className="recent-list">{recent.map((lead,i)=><div className="recent-row" key={lead.id}><div className={`person-avatar avatar-${i%5}`}>{initials(lead.customer_name||lead.phone)}</div><div className="person-info"><b>{lead.customer_name||'Unnamed lead'}</b><small>{lead.service_or_product||lead.email||lead.phone||'No extra details yet'}</small></div><StatusPill status={lead.lead_status}/><button className="icon-btn row-more" title="Edit lead" onClick={()=>onPage('Leads')}><MoreHorizontal size={18}/></button></div>)}</div>}</section>
 <section className="panel tasks-panel"><div className="panel-heading"><div><h3>Your follow-ups</h3><p>Little things worth remembering.</p></div><button className="round-add" title="Add follow-up" onClick={onNewTask}><Plus size={18}/></button></div>{pending.slice(0,4).length===0?<EmptyState icon={CheckCircle2} title="All caught up!" desc="No open reminders right now." action={<button className="text-link" onClick={onNewTask}>Add a reminder +</button>}/>:<div className="task-list">{pending.slice(0,4).map(task=><div className="task-row" key={task.id}><button className="task-check" title="Mark complete" onClick={()=>onToggleTask(task)}><Check size={14}/></button><div className="task-info"><b>{task.title}</b><small><Clock3 size={12}/> {fmtDate(task.due_date)}</small></div>{task.priority==='high'&&<span className="priority-dot" title="High priority"/>}</div>)}</div>}<button className="full-link" onClick={()=>onPage('Follow-ups')}>See all follow-ups <span>→</span></button></section></div>
 <div className="bottom-note"><div className="note-sparkle"><Sparkles size={18}/></div><div><b>A friendly reminder</b><p>It's okay to take it one thing at a time. Your CRM is here to help, not overwhelm.</p></div><span className="note-flower">✿</span></div></>;
}
function StatCard({title,value,note,icon:Icon,tint,trend}){return <div className="stat-card"><div className="stat-top"><span>{title}</span><div className={`stat-icon ${tint}`}><Icon size={19}/></div></div><div className="stat-value">{value}</div><div className="stat-bottom"><span>{note}</span><span className="stat-trend">{trend}</span></div></div>}
function StatusPill({status}){const cls={'New Lead':'new','Contacted':'contacted','Qualified':'qualified','Won':'won','Lost':'lost'}[status]||'new';return <span className={`status-pill ${cls}`}><i/>{status||'New Lead'}</span>}
function EmptyState({icon:Icon,title,desc,action}){return <div className="empty-state"><div className="empty-icon"><Icon size={22}/></div><b>{title}</b><p>{desc}</p>{action}</div>}
function EmptyInline({children}){return <div className="empty-inline">{children}</div>}
function LeadsPage({leads,query,setQuery,statusFilter,setStatusFilter,onNew,onEdit,onDelete,onStatus,loading}) {
 return <><PageHeading eyebrow="YOUR PEOPLE, ALL TOGETHER" title="Leads & contacts" subtitle="Every conversation starts with a person. Keep yours close." action={<button className="btn btn-primary" onClick={onNew}><Plus size={18}/> Add a lead</button>}/><section className="panel table-panel"><div className="table-toolbar"><div className="search-box"><Search size={17}/><input placeholder="Search name, phone, email…" value={query} onChange={e=>setQuery(e.target.value)}/>{query&&<button onClick={()=>setQuery('')}><X size={15}/></button>}</div><div className="filter-box"><Filter size={16}/><select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option>All statuses</option>{STATUSES.map(s=><option key={s}>{s}</option>)}</select></div><span className="results-count">{leads.length} {leads.length===1?'person':'people'}</span></div>{loading?<EmptyInline>Loading leads…</EmptyInline>:leads.length===0?<EmptyState icon={Search} title="No leads found" desc="Try a different search, or add a new lead to get started." action={<button className="btn btn-primary btn-small" onClick={onNew}><Plus size={16}/> Add a lead</button>}/>:<div className="table-scroll"><table><thead><tr><th>CONTACT</th><th>INTEREST</th><th>STATUS</th><th>FOLLOW-UP</th><th>SOURCE</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>{leads.map((lead,i)=><tr key={lead.id}><td><div className="table-person"><div className={`person-avatar avatar-${i%5}`}>{initials(lead.customer_name||lead.phone)}</div><div><b>{lead.customer_name||'Unnamed lead'}</b><small>{lead.email||lead.phone||'No contact details'}</small></div></div></td><td>{lead.service_or_product||<span className="muted">Not specified</span>}</td><td><select aria-label={`Status for ${lead.customer_name}`} className={`status-select ${({'New Lead':'new','Contacted':'contacted','Qualified':'qualified','Won':'won','Lost':'lost'})[lead.lead_status]||'new'}`} value={lead.lead_status||'New Lead'} onChange={e=>onStatus(lead,e.target.value)}>{STATUSES.map(s=><option key={s}>{s}</option>)}</select></td><td>{lead.follow_up_date?fmtDate(lead.follow_up_date):<span className="muted">Not set</span>}</td><td><span className="source-label">{lead.source||'Other'}</span></td><td><div className="row-actions"><button className="icon-btn" title="Edit lead" onClick={()=>onEdit(lead)}><Pencil size={16}/></button><button className="icon-btn danger-hover" title="Delete lead" onClick={()=>onDelete(lead)}><Trash2 size={16}/></button></div></td></tr>)}</tbody></table></div>}<div className="table-foot"><span>💜 A good connection is always worth keeping.</span><span>Showing {leads.length} records</span></div></section></>;
}
function TasksPage({tasks,onNew,onToggle,onDelete}) {
 const [filter,setFilter]=useState('all');
 const shown=tasks.filter(t=>filter==='all'||(filter==='open'?t.status!=='completed':t.status==='completed'));
 return <><PageHeading eyebrow="A LITTLE NUDGE, RIGHT ON TIME" title="Follow-ups" subtitle="A clear next step makes everything feel easier." action={<button className="btn btn-primary" onClick={onNew}><Plus size={18}/> Add a reminder</button>}/><div className="task-summary"><div><span className="summary-icon peach"><Clock3/></span><span><b>{tasks.filter(t=>t.status!=='completed').length}</b><small>Open reminders</small></span></div><div><span className="summary-icon mint"><CheckCircle2/></span><span><b>{tasks.filter(t=>t.status==='completed').length}</b><small>Completed</small></span></div><div><span className="summary-icon lilac"><CalendarDays/></span><span><b>{tasks.filter(t=>t.due_date===new Date().toISOString().slice(0,10)&&t.status!=='completed').length}</b><small>Due today</small></span></div></div><section className="panel tasks-page-panel"><div className="task-page-toolbar"><h3>Your task list</h3><div className="segmented">{[['all','Everything'],['open','To do'],['done','Completed']].map(([id,label])=><button key={id} className={filter===id?'selected':''} onClick={()=>setFilter(id)}>{label}</button>)}</div></div>{shown.length===0?<EmptyState icon={ListTodo} title={filter==='done'?'Nothing completed just yet':'A little breathing room'} desc={filter==='done'?'Completed reminders will show up here.':'No reminders here. Add one whenever something needs your attention.'} action={<button className="btn btn-primary btn-small" onClick={onNew}><Plus size={16}/> Add a reminder</button>}/>:<div className="task-page-list">{shown.map(t=><div className={`task-card ${t.status==='completed'?'is-done':''}`} key={t.id}><button className={`task-check ${t.status==='completed'?'checked':''}`} onClick={()=>onToggle(t)} title={t.status==='completed'?'Mark as open':'Mark completed'}><Check size={15}/></button><div className="task-card-copy"><b>{t.title}</b>{t.description&&<p>{t.description}</p>}<div className="task-meta"><span><CalendarDays size={13}/>{fmtDate(t.due_date)}</span>{t.priority==='high'&&<span className="high-priority">High priority</span>}{t.priority==='low'&&<span className="low-priority">Low priority</span>}</div></div><span className={`task-state ${t.status==='completed'?'done':''}`}>{t.status==='completed'?'Completed':'To do'}</span><button className="icon-btn danger-hover" title="Delete reminder" onClick={()=>onDelete(t)}><Trash2 size={16}/></button></div>)}</div>}</section></>;
}
function ActivityPage({activities,leads}) {
 const leadName=id=>leads.find(l=>l.id===id)?.customer_name;
 return <><PageHeading eyebrow="THE LITTLE THINGS ADD UP" title="Recent activity" subtitle="A gentle timeline of what’s been happening."/><section className="panel activity-panel">{activities.length===0?<EmptyState icon={Activity} title="Your timeline starts here" desc="When you add or update leads, the activity will appear here."/>:<div className="timeline">{activities.map(a=><div className="timeline-row" key={a.id}><div className={`timeline-icon ${a.activity_type==='created'?'mint':a.activity_type==='status_change'?'lilac':'peach'}`}>{a.activity_type==='created'?<Plus size={17}/>:a.activity_type==='status_change'?<Activity size={17}/>:<MessageCircle size={17}/>}</div><div className="timeline-copy"><b>{a.content}</b><p>{leadName(a.lead_id)&&<span>{leadName(a.lead_id)} · </span>}{new Date(a.created_at).toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'})}</p></div><span className="activity-type">{a.activity_type.replace('_',' ')}</span></div>)}</div>}</section></>;
}
function SettingsPage({userEmail,onSignOut,showNotice}){return <><PageHeading eyebrow="YOUR SPACE, YOUR WAY" title="Settings" subtitle="A few helpful details about your workspace."/><div className="settings-grid"><section className="panel settings-card"><div className="settings-heading"><div className="settings-symbol lilac"><ContactRound/></div><div><h3>Your account</h3><p>Account details and sign-in.</p></div></div><div className="settings-line"><span>Email address</span><b>{userEmail}</b></div><div className="settings-line"><span>Authentication</span><span className="settings-secure"><CheckCircle2 size={15}/> Supabase Auth</span></div><button className="btn btn-ghost" onClick={onSignOut}><LogOut size={16}/> Sign out</button></section><section className="panel settings-card"><div className="settings-heading"><div className="settings-symbol mint"><Command/></div><div><h3>Integrations</h3><p>Ready for your next chapter.</p></div></div><div className="integration-row"><div className="integration-icon supa">S</div><div><b>Supabase</b><small>Authentication & live database</small></div><span className="integration-status"><i/> Connected</span></div><div className="integration-row"><div className="integration-icon n8n">n8n</div><div><b>n8n automation</b><small>WhatsApp, lead capture & reminders</small></div><span className="integration-status planned">Next step</span></div><button className="btn btn-ghost" onClick={()=>showNotice('Next: create an authenticated n8n webhook and store its secret in n8n Credentials.')}>Integration setup notes <ArrowUpRight size={16}/></button></section></div><div className="bottom-note"><div className="note-sparkle"><Sparkles size={18}/></div><div><b>Your privacy matters</b><p>Your leads, tasks and activity are protected by Supabase Row Level Security and tied to your signed-in account.</p></div><span className="note-flower">✿</span></div></>}

function Modal({title,subtitle,onClose,children}) {return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section className="modal"><div className="modal-heading"><div><h2>{title}</h2><p>{subtitle}</p></div><button className="icon-btn" onClick={onClose} title="Close"><X size={19}/></button></div>{children}</section></div>}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
